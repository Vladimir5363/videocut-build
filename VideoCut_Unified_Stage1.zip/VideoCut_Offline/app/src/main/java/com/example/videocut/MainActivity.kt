package com.example.videocut

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VideoCutScreen(this) } }
    }
}

@Composable
private fun VideoCutScreen(context: Context) {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var clipLength by remember { mutableFloatStateOf(30f) }
    var subtitleStyle by remember { mutableStateOf("Белые с обводкой") }
    var quality by remember { mutableStateOf("1080p") }
    var downloading by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember {
        mutableStateOf(if (File(context.filesDir, "models/ggml-tiny.bin").exists()) "Модель Whisper tiny уже скачана" else "Модель ещё не скачана")
    }
    val scope = rememberCoroutineScope()
    val modelFile = remember { File(context.filesDir, "models/ggml-tiny.bin") }
    val modelReady = modelFile.exists() && modelFile.length() > 70_000_000L
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selectedVideo = it }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("VideoCut", style = MaterialTheme.typography.headlineLarge)
        Text("Локальный видеоредактор — подключение распознавания речи")

        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (selectedVideo == null) "Выбрать длинное видео" else "Выбрать другое видео")
        }
        Text(if (selectedVideo == null) "Видео не выбрано" else "Видео выбрано")

        HorizontalDivider()
        Text("Шаг 1. Модель распознавания речи", style = MaterialTheme.typography.titleLarge)
        Text("Whisper tiny · русский язык · около 78 МБ. Скачивается один раз и хранится в памяти приложения.")
        if (downloading) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("Загрузка: ${(progress * 100).toInt()}%")
        }
        Text(status, style = MaterialTheme.typography.bodyMedium)
        Button(
            onClick = {
                scope.launch {
                    downloading = true
                    progress = 0f
                    status = "Подключаемся к Hugging Face…"
                    try {
                        downloadWhisperTiny(context) { value ->
                            progress = value
                            status = "Загружаем модель… ${(value * 100).toInt()}%"
                        }
                        status = "Модель скачана и проверена. Следующий шаг — подключить движок распознавания."
                    } catch (e: Exception) {
                        status = "Не удалось скачать модель: ${e.message ?: "проверь интернет и повтори"}"
                    } finally {
                        downloading = false
                    }
                }
            },
            enabled = !downloading && !modelReady,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(when { downloading -> "Скачивание…"; modelReady -> "Модель уже скачана"; else -> "Скачать модель Whisper tiny (78 МБ)" })
        }

        HorizontalDivider()
        Text("Настройки будущих клипов", style = MaterialTheme.typography.titleLarge)
        Text("Длительность клипов: ${clipLength.toInt()} секунд")
        Slider(value = clipLength, onValueChange = { clipLength = it }, valueRange = 10f..90f)
        Text("Стиль русских субтитров")
        listOf("Белые с обводкой", "Жёлтые", "Минималистичные").forEach { option ->
            Row {
                RadioButton(selected = subtitleStyle == option, onClick = { subtitleStyle = option })
                Text(option, Modifier.padding(top = 12.dp))
            }
        }
        Text("Качество")
        listOf("720p", "1080p", "Исходное").forEach { option ->
            Row {
                RadioButton(selected = quality == option, onClick = { quality = option })
                Text(option, Modifier.padding(top = 12.dp))
            }
        }
        Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
            Text("Распознавание и нарезка — следующий этап")
        }
        Text(
            "Важно: на этом этапе приложение умеет скачать и сохранить файл модели. Сам движок Whisper, анализ интересных моментов, нарезка и экспорт ещё не подключены. Видео пока не обрабатывается.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private suspend fun downloadWhisperTiny(context: Context, onProgress: (Float) -> Unit) {
    withContext(Dispatchers.IO) {
        val directory = File(context.filesDir, "models")
        if (!directory.exists() && !directory.mkdirs()) error("не удалось создать папку модели")
        val target = File(directory, "ggml-tiny.bin")
        val temporary = File(directory, "ggml-tiny.bin.part")
        val expectedSha256 = "be07e048e1e599ad46341c8d2a135645097a538221678b7acdd1b1919c6e1b21"

        if (target.exists() && target.length() > 70_000_000L && sha256(target) == expectedSha256) {
            withContext(Dispatchers.Main) { onProgress(1f) }
            return@withContext
        }
        target.delete()
        temporary.delete()

        val connection = (URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin").openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            requestMethod = "GET"
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) error("сервер вернул HTTP $code")
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                temporary.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var downloaded = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        downloaded += count
                        if (total > 0) {
                            val value = (downloaded.toFloat() / total).coerceIn(0f, 1f)
                            withContext(Dispatchers.Main) { onProgress(value) }
                        }
                    }
                }
            }
            if (temporary.length() < 70_000_000L) error("файл получился неполным")
            if (sha256(temporary) != expectedSha256) error("контрольная сумма не совпала; скачай модель ещё раз")
            if (!temporary.renameTo(target)) error("не удалось сохранить модель")
            withContext(Dispatchers.Main) { onProgress(1f) }
        } finally {
            connection.disconnect()
            if (temporary.exists()) temporary.delete()
        }
    }
}

private fun sha256(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(128 * 1024)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            digest.update(buffer, 0, count)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
