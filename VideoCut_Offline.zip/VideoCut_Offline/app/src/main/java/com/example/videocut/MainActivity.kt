package com.example.videocut

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VideoCutScreen() } }
    }
}

@Composable
private fun VideoCutScreen() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var clipLength by remember { mutableFloatStateOf(30f) }
    var subtitleStyle by remember { mutableStateOf("Белые с обводкой") }
    var quality by remember { mutableStateOf("1080p") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selectedVideo = it }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("VideoCut", style = MaterialTheme.typography.headlineLarge)
        Text("Локальный видеоредактор — подготовка проекта")
        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (selectedVideo == null) "Выбрать длинное видео" else "Выбрать другое видео")
        }
        Text(if (selectedVideo == null) "Видео не выбрано" else "Видео выбрано")
        HorizontalDivider()
        Text("Длительность клипов: ${clipLength.toInt()} секунд")
        Slider(value = clipLength, onValueChange = { clipLength = it }, valueRange = 10f..90f)
        Text("Стиль русских субтитров")
        listOf("Белые с обводкой", "Жёлтые", "Минималистичные").forEach { option ->
            Row { RadioButton(selected = subtitleStyle == option, onClick = { subtitleStyle = option }); Text(option, Modifier.padding(top = 12.dp)) }
        }
        Text("Качество")
        listOf("720p", "1080p", "Исходное").forEach { option ->
            Row { RadioButton(selected = quality == option, onClick = { quality = option }); Text(option, Modifier.padding(top = 12.dp)) }
        }
        Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("Найти интересные фрагменты — движок ещё не подключён") }
        Text("Важно: это стартовая версия интерфейса. Автоматическое распознавание речи, поиск моментов, нарезка и экспорт пока не реализованы.", style = MaterialTheme.typography.bodySmall)
    }
}
